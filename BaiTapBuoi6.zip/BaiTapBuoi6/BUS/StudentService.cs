﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using DAL.Models;
using static BUS.StudentService;

namespace BUS
{
    public class StudentService
    {
        StudentDBContext context = new StudentDBContext();
        //viet ham lay danh sach sinh vien

        public class sinhvien
        {
            public string MSSV { get; set; }
            public string Name { get; set; }
            public double? AverageScore { get; set; }
            public string FacultyName { get; set; }
        }
        public List<sinhvien> GetAll()
        {
            var sinhvien = from student in context.Student
                                  join faculty in context.Faculty
                                  on student.FacultyID equals faculty.FacultyID
                                  select new sinhvien
                                  {
                                      MSSV = student.MSSV,
                                      Name = student.Name,
                                      AverageScore = student.AverageScore,
                                      FacultyName = faculty.FacultyName
                                  };

            return sinhvien.ToList();
        }
        public List<Faculty> GetFaculties()
        {
            return context.Faculty.ToList(); 
        }
        public void AddStudent(string mssv, string name, double? avgScore, string facultyId)
        {
            try
            {
                var newStudent = new Student
                {
                    MSSV = mssv,
                    Name = name,
                    AverageScore = avgScore,
                    FacultyID = facultyId
                };

                context.Student.Add(newStudent);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi thêm sinh viên: " + ex.Message);
            }
        }
        public void UpdateStudent(string mssv, string name, double? avgScore, string facultyId)
        {
            try
            {
                // Tìm sinh viên theo MSSV
                var student = context.Student.FirstOrDefault(s => s.MSSV == mssv);

                // Nếu không tìm thấy sinh viên
                if (student == null)
                {
                    throw new Exception("Sinh viên không tồn tại");
                }

                // Cập nhật thông tin sinh viên
                student.Name = name;
                student.AverageScore = avgScore;
                student.FacultyID = facultyId;

                // Lưu thay đổi vào cơ sở dữ liệu
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                // Xử lý lỗi (ví dụ: ghi lỗi vào log hoặc hiển thị thông báo cho người dùng)
                throw new Exception("Lỗi khi sửa sinh viên: " + ex.Message);
            }
        }
        public void DeleteStudent(string mssv)
        {
            try
            {
                var student = context.Student.FirstOrDefault(s => s.MSSV == mssv);
                if (student != null)
                {
                    context.Student.Remove(student);
                    context.SaveChanges();
                }
                else
                {
                    throw new Exception("Sinh viên không tồn tại");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi xóa sinh viên: " + ex.Message);
            }
        }

    }
}
