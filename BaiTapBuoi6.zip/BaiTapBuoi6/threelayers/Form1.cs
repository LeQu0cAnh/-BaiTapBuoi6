﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using BUS;
using DAL.Models;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace threelayers
{
    public partial class Form1 : Form
    {
        StudentDBContext context = new StudentDBContext();
        private readonly StudentService _studentService =   new StudentService();    
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var students = _studentService.GetAll();
            dataGridView1.DataSource = students;
            Loadfaculty();
            cmb_fac.SelectedIndex = -1;

        }
        //cập nhật lại faculty
        public void Loadfaculty()
        {
            var faculties = _studentService.GetFaculties(); 
            cmb_fac.DataSource = faculties;
            cmb_fac.DisplayMember = "FacultyName"; 
            cmb_fac.ValueMember = "FacultyID";
        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            Loadfaculty();
            var mssv = txt_mssv.Text;
            var name = txt_name.Text;
            var avgScore = double.TryParse(txt_dtb.Text, out var avg) ? (double?)avg : null;
            var facultyID = cmb_fac.SelectedValue.ToString(); 
            _studentService.AddStudent(mssv, name, avgScore, facultyID);

            var students = _studentService.GetAll();
            dataGridView1.DataSource = students;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                
                var selectedStudent = dataGridView1.Rows[e.RowIndex].DataBoundItem as StudentService.sinhvien;
                if (selectedStudent != null)
                {
                    txt_mssv.Text = selectedStudent.MSSV;
                    txt_name.Text = selectedStudent.Name;
                    txt_dtb.Text = selectedStudent.AverageScore?.ToString();
                    var faculties = _studentService.GetFaculties();
                    cmb_fac.DataSource = faculties;
                    cmb_fac.DisplayMember = "FacultyName"; 
                    cmb_fac.ValueMember = "FacultyName";
                    cmb_fac.SelectedValue = selectedStudent.FacultyName; 
                }
            }
        }

        

        private void btn_fix_Click(object sender, EventArgs e)
        {
            Loadfaculty();
            var mssv = txt_mssv.Text;
            var name = txt_name.Text;
            var avgScore = double.TryParse(txt_dtb.Text, out var avg) ? (double?)avg : null;
            var facultyID = cmb_fac.SelectedValue.ToString();

            try
            {
                // Gọi phương thức sửa thông tin sinh viên trong StudentService
                _studentService.UpdateStudent(mssv, name, avgScore, facultyID);

                // Cập nhật lại danh sách sinh viên trong DataGridView
                var students = _studentService.GetAll();
                dataGridView1.DataSource = students;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            var mssv = txt_mssv.Text;
            _studentService.DeleteStudent(mssv);
            var students = _studentService.GetAll();
            dataGridView1.DataSource = students;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
